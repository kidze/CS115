import java.io.File;
import java.io.IOException;
import java.util.Scanner;
public class VehicleClient
{
	public static void main(String[] args)
	{
		int[] timearray = null;
		int counter = 0;
		int counter2 = 0;
		
		try
		{
			File timefile = new File("Time.txt");
			//count the number of integers
			Scanner scanner1 = new Scanner(timefile);
			while(scanner1.hasNextInt())
			{
				scanner1.nextInt();
				counter++;
			}
			timearray = new int[counter];
			
			//set data to array
			Scanner scanner2 = new Scanner(timefile);
		
			while(scanner2.hasNextInt())
			{
				timearray[counter2] = scanner2.nextInt();
				counter2++;
			}
		}
		catch(IOException e)
		{
			System.out.println("There is something wrong with the file");
		}
		
		//create Vehicle objects
		for(int i = 0; i<= timearray.length-1; i++)
		{
			Vehicle vehicle = new Vehicle("BMW",2.0, timearray[i],0.0,0.0);
			vehicle.calculateV();
			vehicle.calculateD();
			System.out.println(vehicle.toString());
		}
	}
}