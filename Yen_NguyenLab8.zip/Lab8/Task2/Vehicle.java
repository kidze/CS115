public class Vehicle
{
	String vehicle_type = "";
	double velocity = 0.0;
	double acceleration = 0.0;
	double distance = 0.0;
	int time = 0;
	double init_v = 0.0;
	double init_d = 0.0;
	static int vehicleID = 0;
	int currentID = 0;
	
	//default constructor
	public Vehicle()
	{
		vehicle_type = "";
		velocity = 0;
		acceleration = 0;
		distance = 0;
		time = 0;
		init_d = 0;
		init_v = 0;
		vehicleID++;
		currentID = vehicleID;
	}
	
	//non-default constructor
	public Vehicle(String type, double a, int t, double initv, double initd)
	{
		vehicle_type = type;
		velocity = 0;
		acceleration = a;
		distance = 0;
		time = t;
		init_v = initv;
		init_d = initd;
		vehicleID++;
		currentID = vehicleID;
	}
	
	//accessor methods
	public String getVehicleType(){return vehicle_type;}
	public double getVelocity(){return velocity;}
	public double getAcceleration(){return acceleration;}
	public double getDistance(){return distance;}
	public int getTime(){return time;}
	public double getInitVelocity(){return init_v;}
	public double getInitDistance(){return init_d;}
	public int getVehicleID(){return vehicleID;}
	public int getCurrentID(){return currentID;}
	
	//mutator methods
	public void setVehicleType(String ntype){vehicle_type = ntype;}
	public void setVelocity(double nv){velocity = nv;}
	public void setAcceleration(double na){acceleration = na;}
	public void setDistance(double nd){distance = nd;}
	public void setTime(int nt){time = nt;}
	public void setInitVelocity(double niv){init_v = niv;}
	public void setInitDistance(double nid){init_d = nid;}
	public void setVehicleID(int nvid){vehicleID = nvid;}
	public void setCurrentID(int ncid){currentID = ncid;}
	
	//specific mutator method
	//velocity
	public void calculateV()
	{velocity = acceleration*time + init_v;}
	//distance
	public void calculateD()
	{distance = init_d + init_v*time + 0.5*acceleration*Math.pow(time,2);}
	
	//toString method
	public String toString()
	{
		String output = "Current ID: "+currentID+". Type: "+vehicle_type+". Time: "+time+". Acceleration: "+acceleration+". Velocity: "+velocity+". Distance: "+distance;
		return output;
	}
}