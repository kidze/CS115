import java.text.DecimalFormat;
public class SoccerPlayer
{
	String name = "";
	int goals = 0;
	int games = 0;
	String team = "";
	static int ID = 0;
	int currentID = 0;
	
	//default constructor
	public SoccerPlayer(){
		name = "Yen";
		goals = 1;
		games = 1;
		team = "Boys";
		ID++;
		currentID = ID;
	}
	
	//non-default constructor
	public SoccerPlayer(String n, int ga, String t){
		name = n;
		goals = 0;
		games = ga;
		team = t;
		ID++;
		currentID = ID;
	}
	
	//accessors
	public String getName(){return name;}
	public int getGoals(){return goals;}
	public int getGames(){return games;}
	public String getTeam(){return team;}
	public int getID(){return ID;}
	public int getCurrentID(){return currentID;}
	//mutators
	public void setName(String n){name = n;}
	public void setGoals(int g){goals = g;}
	public void setGames(int ga){games = ga;}
	public void setTeam(String t){team = t;}
	public void setID(int i){ID = i;}
	public void setCurrentID(int c){currentID = c;}
	
	//toString method
	public String toString(){
		return "Name: "+name+".\t\tTotal goals: "+goals+".\t\tTotal games: "+games+".\t\tTeam: "+team+".\t\tPlayer ID: "+currentID;
	}
	
	//averageGoals method
	public String averageGoals(){
		DecimalFormat fm = new DecimalFormat("0.000");
		double output = (double)goals/(double)games;
		if(goals <= 0 || games <= 0)
			return "1000000.000";
		else
			return fm.format(output);
	}
	
	//equals method
	public boolean equals(SoccerPlayer anotherPlayer){
		if(Double.parseDouble(this.averageGoals()) > 0 && Double.parseDouble(anotherPlayer.averageGoals()) > 0)
			if(this.getTeam().equals(anotherPlayer.getTeam()) && Double.parseDouble(this.averageGoals()) == Double.parseDouble(anotherPlayer.averageGoals()))
				return true;
			else
				return false;
		else
			return false;
	}
}