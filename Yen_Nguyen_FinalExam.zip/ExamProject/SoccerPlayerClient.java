import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.text.DecimalFormat;
public class SoccerPlayerClient
{
	public static void main(String[] args)
	{
		StringTokenizer[] lines = null;
		SoccerPlayer[] playerArray = null;
		
		try{
			File file = new File("player.txt");
			Scanner scanCount = new Scanner(file);
			Scanner scanData = new Scanner(file);
			//count the number of lines
			int counter = 0;
			while(scanCount.hasNextLine()){
				scanCount.nextLine();
				counter++;
			}
			//initialize size of token array
			lines = new StringTokenizer[counter];
			
			//put data into token array
			for(int i = 0; i<= lines.length-1; i++){
				lines[i] = new StringTokenizer(scanData.nextLine(),",");
			}
			//initialize sizze of player array
			playerArray = new SoccerPlayer[lines.length];
			
			//put data into playerArray
			for(int i = 0; i<= lines.length - 1; i++){
				playerArray[i] = new SoccerPlayer(lines[i].nextToken(), Integer.parseInt(lines[i].nextToken()), lines[i].nextToken());
			}
		}
		catch(IOException e){
			System.out.println("There is something wrong with the file");
		}
		//user input goals
		Scanner scanInput = new Scanner(System.in);
		int iteration = 0;
		while(iteration <= playerArray.length-1){
			System.out.println("Please enter the number of goals for the player number "+ playerArray[iteration].getCurrentID());
			if(scanInput.hasNextInt()){
				int input = scanInput.nextInt();
				if(input == -1)
					System.exit(0);
				else{
					playerArray[iteration].setGoals(input);
					if(playerArray[iteration].averageGoals().equals("1000000.000"))
						System.out.println("The average can't be calculated for player with ID = "+playerArray[iteration].getCurrentID());
					else
						System.out.println("Average goals: "+playerArray[iteration].averageGoals());
				}
			}
			else{
				String c = scanInput.next();
				if(c.equals("c")){
					System.out.println("Okay, you want to repeat the loop");
					System.out.println();
					iteration = -1;
				}
			}
			iteration++;
		}
		//create array for valid player
		SoccerPlayer[] validPlayers = null;
		//count the number of valid players
		int countvalid = 0;
		for(int i = 0; i<=  playerArray.length-1; i++){
			if(!playerArray[i].averageGoals().equals("1000000.000"))
				countvalid++;
		}
		//initialize the size of valid player array
		validPlayers = new SoccerPlayer[countvalid];
		//set data of valid players into valid players array
		int index = 0;
		for(int i = 0; i< playerArray.length-1; i++){
			if(!playerArray[i].averageGoals().equals("1000000.000")){
				validPlayers[index] = playerArray[i];
				index++;
			}
		}
		//check for the highest average goals
		double highest = 0.0;
		for(int i = 0; i<= validPlayers.length-1; i++){
			if(Double.parseDouble(validPlayers[i].averageGoals()) > highest)
				highest = Double.parseDouble(validPlayers[i].averageGoals());
		}
		
		//print the player with highest average
		System.out.println();
		for(int i = 0; i<= validPlayers.length-1; i++){
			if(Double.parseDouble(validPlayers[i].averageGoals()) == highest)
				System.out.println("The player with the highest average is: "+validPlayers[i].toString().concat(". Average goals: "+validPlayers[i].averageGoals()));
		}
		//print the sum of average
		System.out.println();
		DecimalFormat format = new DecimalFormat("0.000");
		System.out.println("The sum of all average is: "+format.format(calculateSumOfAverages(validPlayers)));
		
	}
	public static double calculateSumOfAverages(SoccerPlayer[] array){
		double output = 0.0;
		for(int i = 0; i<= array.length-1; i++){
			output = output + Double.parseDouble(array[i].averageGoals());
		}
		return output;
	}
}