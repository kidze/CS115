public class ShortcutOperatorsWithTypecasting
{
	public static void main(String[] args)
    { 
		int count = 0;
			System.out.println("Today is Wednesday");
			count+=1;
            System.out.println("There is a chance of rain today");
			count++;
			System.out.println("Tonight I am going to the movies");
			count++;
			System.out.println("Tomorrow I am going to the ballgame"); 
			count++;
			
			System.out.println(count);
			
		double doublecount= (double)count++;
		
		System.out.println("The number of output statements after postifx increment and double conversion is: "+doublecount);
		System.out.println("The number of output statements after postifx increment is "+count);
		
		float floatcount=(float)++doublecount;
		
		System.out.println("The number of output statements after float conversion and prefix increment is: "+floatcount);
		System.out.println("The number of output statements after prefix increment is: "+doublecount);
		double newcount=count+doublecount;
		
		System.out.println(newcount);

	}
}

