public class ShortcutOperatorTest
{
	public static void main(String[] args)
    { 
		int a = 0;
			System.out.println("Today is Wednesday");
			a+=1;
            System.out.println("There is a chance of rain today");
			a++;
			System.out.println("Tonight I am going to the movies");
			a++;
			System.out.println("Tomorrow I am going to the ballgame"); 
			a++;
			
			System.out.println(a);
	}
}

