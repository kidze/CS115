import java.util.Scanner;
import java.io.*;

public class Grades
{
	public char letterGrade(int a)
	{
		char output = 'x';
		if(a<=100)
			output = 'A';
		else if(a<=90)
			output = 'B';
		else if(a<=80)
			output = 'C';
		else if(a<=70)
			output = 'D';
		else if(a<60)
			output = 'E';
		return output;
	}
	
	public static void main(String[] args)
	{
		int counter = 0;
		int sum = 0;
		int max =  0;
		int maxIndex = 0;
		int[] array = null;
		try
		{
			File gradesFile = new File("MyGrades.txt");
			Scanner scan = new Scanner(gradesFile);
			//find array length
			while(scan.hasNextInt())
			{
				scan.nextInt();
				counter++;
			}
			
			array = new int[counter];
			
			Scanner scan2 = new Scanner(gradesFile);
			//set data to array
			for(int i = 0; i<=array.length-1; i++)
			{
				array[i] = scan2.nextInt();
			}
			
			//calculate sum and max
			for(int j = 0; j<=array.length-1; j++)
			{
				sum = sum +array[j];
				if(array[j]>max)
				{
					max = array[j];
					maxIndex = j;
				}
			}
		}
		
		catch(IOException e)
		{
			System.out.println("There is something wrong.");
		}
		
		//print
		double average = sum/array.length;
		System.out.println("The largest is: "+max+" at position "+maxIndex);
		System.out.println("The sum is: "+sum);
		System.out.println("The average is: "+average);
		
		//letterGrade
		Grades g = new Grades();
		System.out.println("The largest grade number "+max+ " corresponds to letter grade "+g.letterGrade(max));
	}
}