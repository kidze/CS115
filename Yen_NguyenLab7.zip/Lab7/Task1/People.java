public class People  {
	
    String firstName=" ";
    String lastName=" ";
	int socialSecurity=0;
	double height=0.0;
    static int id = 0;
	int personID = 0;
	
	//default constructor
	public People()
	{
		id++;
		personID = id;
        firstName="AnyName";
		lastName="AnyName";
		socialSecurity=123456789;
		height=5.8;
	}
	
	public People(String fn, String ln, int ssn, double ht)
	{
		id++;
		personID = id;
        firstName=fn;
		lastName=ln;
		socialSecurity=ssn;
		height=ht;
	}

	//accessor
	public String getFirstName()
	{
		return firstName;
	}

	public String getLastName()
	{
		return lastName;
	}

	public int getSocialSecurity()
	{
		return socialSecurity;
	}

	public double getHeight()
	{
		return height;
	}
	
	public int getId()
	{
		return id;
	}
	
	public int getPersonID()
	{
		return personID;
	}

	//mutator
	public void setFirstName(String fina)
	{
		firstName=fina;
	}

	public void setLastName(String lana)
	{
		lastName=lana;
	}

	public void setSocialSecurity(int sosec)
	{
		socialSecurity=sosec;
	}

	public void setHeight(double hei)
	{
		height=hei;
	}
	
	public void setId(int nid)
	{
		id = nid;
	}
	
	public void setPersonID(int npersonid)
	{
		personID = npersonid;
	}

	//toString() method
	public String toString()
	{
		String output = "First name: "+firstName+". Last name: "+lastName+". SSN: "+socialSecurity+". Height: "+height+". ID: "+id+". PersonID: "+personID;
		return output;
	}
	
	//equals method
	public boolean equals(People anotherPeople)
	{
		if(this.socialSecurity == anotherPeople.socialSecurity)
			return true;
		else
			return false;
	}
}
