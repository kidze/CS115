import javax.swing.JOptionPane;
import java.util.Scanner;

public class PeopleClient
{
	public static void main(String[] args)
	{
		Scanner scanner = new Scanner(System.in);
		//scan for values
		System.out.println("Please enter person1's first name");
		String firstname = scanner.next();
		
		System.out.println("Please enter person1's last name");
		String lastname = scanner.next();
		
		System.out.println("Please enter person1's social security number");
		int ssn = scanner.nextInt();
		
		System.out.println("Please enter person1's height");
		double height = scanner.nextDouble();
		
		//person1
		People person1 = new People(firstname, lastname, ssn, height);
		
		//values from command line
		String fn2 = args[0];
		String ln2 = args[1];
		int ssn2 = Integer.parseInt(args[2]);
		double height2 = Double.parseDouble(args[3]);
		
		//person2
		People person2 = new People(fn2, ln2, ssn2, height2);
		
		//values for person3
		String fn3 = JOptionPane.showInputDialog(null, "Input","Enter person3's first name", JOptionPane.INFORMATION_MESSAGE);
		
		String ln3 = JOptionPane.showInputDialog(null, "Input","Enter person3's last name", JOptionPane.INFORMATION_MESSAGE);
		
		String ssn3_str = JOptionPane.showInputDialog(null, "Input","Enter person3's ssn", JOptionPane.INFORMATION_MESSAGE);
		int ssn3 = Integer.parseInt(ssn3_str);
		
		String height3_str = JOptionPane.showInputDialog(null, "Input","Enter person3's height", JOptionPane.INFORMATION_MESSAGE);		
		double height3 = Double.parseDouble(height3_str);
		
		//person3
		People person3 = new People(fn3, ln3, ssn3, height3);
		
		//person4
		People person4 = new People("Yen","Nguyen",123198,34.34);
		
		//output person3 on JOptionPane
		JOptionPane.showMessageDialog(null, "The person id of person 3 is: "+person3.getPersonID()+" and the static id value is: "+person3.getId());
		System.out.println("The person id of person 3 is: "+person3.getPersonID()+" and the static id value is: "+person3.getId());
		
		//output values of 4 people
		System.out.println(person1.toString());
		System.out.println(person2.toString());
		System.out.println(person3.toString());
		System.out.println(person4.toString());
		
		//change id to 10
		person1.setId(10);
		System.out.println();
		
		//output values of 4 people again
		System.out.println(person1.toString());
		System.out.println(person2.toString());
		System.out.println(person3.toString());
		System.out.println(person4.toString());

	}
}