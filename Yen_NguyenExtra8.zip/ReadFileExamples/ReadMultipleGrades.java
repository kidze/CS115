//Author:George Koutsogiannakis

//Reading a file by redirecting Scanner
import java.util.*;
import java.io.File;
import java.io.IOException;

public class ReadMultipleGrades
  
{
	public static void main(String[] args) 
	{
		
		
		
		
		String grade=" ";
		int gr=0;
		int countStudents=0;
		
		int average=0;
		//we are going to use the variable iterations to count the number of grades read from the file.
       try
	   {
			File myfile=new File("MultipleGrades.txt");
			Scanner scan=new Scanner(myfile);
			//we are going to read one data (one number) at a time. 
			//the system determines if there is another data to be  read by returning true
			//as long as there is another data, otherwise false.
			
			
			while (scan.hasNextLine())
			{
				String line=scan.nextLine();
				int numOfGradesPerStudent=0;
				//accumulate a total of all grades read
				countStudents++;

				int totalOfGrades=0;
				StringTokenizer strtok=new StringTokenizer(line);
				while(strtok.hasMoreTokens())
				{
					numOfGradesPerStudent++;
					grade=strtok.nextToken();
					gr=Integer.parseInt(grade);

					totalOfGrades=totalOfGrades+gr;
				}
				System.out.println("the number of grades for this student is ="+" "+numOfGradesPerStudent);
				
				System.out.println("The total during this iteration is:"+" "+totalOfGrades);

				 average=totalOfGrades/numOfGradesPerStudent;

				System.out.println("the average grade for this student is:"+" "+average);

				//Now read the next student's grdes (next line)

				
		  }
	   }
	   catch (IOException e)
		{ 
			System.out.println("There is something wrong with the file");
	    }
		
		System.out.println("The number of students graded was="+" "+countStudents);
	}
}
/*---------- OUTPUT ----------
---------- Java Interpreter ----------
C:\CS115\Myexamples\ReadFileExamples>java ReadMultipleGrades
the number of grades for this student is = 9
The total during this iteration is: 664
the average grade for this student is: 73
the number of grades for this student is = 9
The total during this iteration is: 711
the average grade for this student is: 79
the number of grades for this student is = 9
The total during this iteration is: 694
the average grade for this student is: 77
the number of grades for this student is = 3
The total during this iteration is: 268
the average grade for this student is: 89
the number of grades for this student is = 2
The total during this iteration is: 190
the average grade for this student is: 95
The number of students graded was= 5
Output completed (0 sec consumed) - Normal Termination
*/