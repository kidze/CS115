//Author:George Koutsogiannakis

//Reading a file by redirecting Scanner
import java.util.*;
import java.io.File;
import java.io.IOException;

public class ReadGrades
  
{
	public static void main(String[] args) 
	{
		
		
		
		int iterations=0;
		int grade = 0;
		int totalOfGrades=0;
		int index = 0;
		int[] array = null;
		int max = 0;
		//we are going to use the variable iterations to count the number of grades read from the file.
       try
	   {
			File myfile=new File("Grades.txt");
			Scanner scan=new Scanner(myfile);
			
			while (scan.hasNextInt())
			{
				scan.nextInt();
				iterations++;
			}
			
			array = new int[iterations];
			
			Scanner scan2 = new Scanner(myfile);
			
			while (scan2.hasNextInt())
			{
				grade = scan2.nextInt();
				array[index] = grade;
				totalOfGrades = totalOfGrades + array[index];
				index++;
				
		  }
		  
		  for(int i = 0; i<=array.length-1; i++)
		  {
			  if(array[i]>max)
				  max = array[i];
		  }
	   }
	   catch (IOException e)
		{ 
			System.out.println("There is something wrong with the file");
	    }
		int average=totalOfGrades/iterations;
		System.out.println(iterations);
		System.out.println(index);
		System.out.println(max);
		System.out.println("the average grade for this student is:"+" "+average);
	}
}
/*---------- OUTPUT ----------
---------- Java Interpreter ----------
this is iteration #=1
The number read from the file is: 78
The total during this iteration is: 78
this is iteration #=2
The number read from the file is: 88
The total during this iteration is: 166
this is iteration #=3
The number read from the file is: 67
The total during this iteration is: 233
this is iteration #=4
The number read from the file is: 89
The total during this iteration is: 322
this is iteration #=5
The number read from the file is: 55
The total during this iteration is: 377
this is iteration #=6
The number read from the file is: 79
The total during this iteration is: 456
this is iteration #=7
The number read from the file is: 90
The total during this iteration is: 546
this is iteration #=8
The number read from the file is: 53
The total during this iteration is: 599
this is iteration #=9
The number read from the file is: 65
The total during this iteration is: 664
the average grade for this student is: 73

Output completed (0 sec consumed) - Normal Termination
*/