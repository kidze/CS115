import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Scanner;

public class PeopleClient
{
	public static void main(String[] args)
	{
		String firstinput = args[0];
		String secondinput = args[1];
		String thirdinput = args[2];
		String fourthinput = args[3];
		
		int ssn = Integer.parseInt(thirdinput);
		double height = Double.parseDouble(fourthinput);
		
		//person1
		People person1 = new People(firstinput, secondinput, ssn, height);
		System.out.println(person1.toString());
		
		//scan for values
		Scanner scannner = new Scanner(System.in);
		System.out.println("Please enter your first name");
		String firstname = scannner.next();
		
		System.out.println("Please enter your last name");
		String lastname = scannner.next();
		
		System.out.println("Please enter your social security number");
		int newssn = scannner.nextInt();
		
		System.out.println("Please enter your height");
		double newheight = scannner.nextDouble();
		
		//person2
		People person2 = new People(firstname, lastname, newssn, newheight);
		System.out.println(person2.toString());
		
		//person2 modification
		person2.setFirstName("Matthew");
		person2.setLastName("Colbert");
		System.out.println(person2.toString());
		
		//concatinate
		String FirstNameWithSpace = person2.getFirstName().concat(" ");
		String firstlast = FirstNameWithSpace.concat(person2.getLastName());
		System.out.println(firstlast);
		
		//firstlast's length
		int len = firstlast.length();
		System.out.println("The length of String firstlast is: "+len);
		
		//first o's index
		int k = firstlast.indexOf("o");
		System.out.println("The index of the first o in String firstlast is: "+k);
		
		//power
		double sqi = Math.pow(10,k);
		
		//format sqi
		DecimalFormat f = new DecimalFormat("0.00");
		String sqif = f.format(sqi);
		System.out.println("The formatted value of sqi is: "+sqif);
		
		//convert to US dollars
		String sqifd = NumberFormat.getCurrencyInstance().format(sqi);
		System.out.println("The value of sqi in US dollars is: "+sqifd);
	}
}