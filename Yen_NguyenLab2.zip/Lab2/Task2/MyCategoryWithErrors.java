public class MyCategoryWithErrors
{
	public static void main(String[] args)
	{
		int id;
		double age;
		char letter;
		String name;
		id = 35;
		age = 18.68;
		name = "Yen Nguyen";
		
		int identifier = (int)(id*age/10);
		letter = (char)identifier;
		
		System.out.println("My name is"+" "+name+" "+"My category is"+" "+letter);
	}
}