public class MyAverage
{
	public static void main(String[] args)
	{
		int a = 1;
		int b = 7;
		int c = 9;
		int d = 34;
		int e = (a+b+c+d)/4;
		System.out.println(e);
	}
}