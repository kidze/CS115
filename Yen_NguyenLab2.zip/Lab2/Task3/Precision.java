public class Precision 
{
	public static void main(String[] args) 
	{
		int x=5;
		int y=3;
		int resulti=(int)5/3;
		double resultd=5/3;
		double resultd1=5.0/3.0;
		float resultf=(float)5/3;
		System.out.println("The int result is:"+" "+resulti);
		System.out.println("The double result without double typecasting is:"+" "+resultd);
		System.out.println("The double result with double typecasting is:"+" "+resultd1);
		System.out.println("The float result is:"+" "+resultf);
		
	}
}
