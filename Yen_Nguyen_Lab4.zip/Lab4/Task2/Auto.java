public class Auto
{
	String autoName = " ";
	int milesDriven = -1;
	
	//default constructor
	public Auto()
	{
		autoName = "Anycar";
		milesDriven = 100;
	}
	
	//non-default constructor
	public Auto(String name, int miles)
	{
		autoName = name;
		milesDriven = miles;
	}
	
	//accessoor methods
	public String getAutoName()
	{
		return autoName;
	}
	
	public int getMilesDriven()
	{
		return milesDriven;
	}
	
	//mutator methods
	public void setAutoName(String newname)
	{
		autoName = newname;
	}
	
	public void setMilesDriven(int newmd)
	{
		milesDriven = newmd;
	}
	
	//toString method
	public String toString()
	{
		String out="the auto name is:"+" "+autoName+" "+"The miles driven are:"+" "+milesDriven;
		return out;
	}
	
	
}