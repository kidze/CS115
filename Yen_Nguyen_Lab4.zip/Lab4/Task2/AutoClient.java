public class AutoClient
{
	public static void main(String[] args)
	{
		Auto car = new Auto("FORD",1000);
		System.out.println(car.toString());
	}
}