public class PPoint
{
	public int x_coordinate;
	public int y_coordinate;
	
	//default constructor
	public PPoint()
	{
		x_coordinate = 0;
		y_coordinate = 0;
	}
	
	//non-default constructor
	public PPoint(int x, int y)
	{
		x_coordinate = x;
		y_coordinate = y;
	}
	
	//accessor methods
	public int getX()
	{
		return x_coordinate;
	}
	public int getY()
	{
		return y_coordinate;
	}
	
	//mutator methods
	public void setX(int newx)
	{
		x_coordinate = newx;
	}
	public void setY(int newy)
	{
		y_coordinate = newy;
	}
	
	
	//toString() method
	public String toString()
	{
		String output = "("+x_coordinate+","+y_coordinate+")";
		return output;
	}
	
	//calculate distance from origin method
	public double distanceFromOrigin()
	{
		double result = Math.sqrt(Math.pow(x_coordinate,2)+Math.pow(y_coordinate,2));
		return result;
	}
	
	
}