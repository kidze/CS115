import java.util.Scanner;

public class PPointClient
{
	public static void main(String[] args)
	{
		//first point
		System.out.println("Please enter the x-coordinate for your first point.");
		Scanner scanner1 = new Scanner(System.in);
		int x1 = scanner1.nextInt();
		
		System.out.println("Please enter the y-coordinate for your first point.");
		Scanner scanner2 = new Scanner(System.in);
		int y1 = scanner2.nextInt();
		
		PPoint p1 = new PPoint(x1, y1);
		
		
		//second point
		System.out.println("Please enter the x-coordinate for your second point.");
		Scanner scanner3 = new Scanner(System.in);
		int x2 = scanner3.nextInt();
		
		System.out.println("Please enter the y-coordinate for your second point.");
		Scanner scanner4 = new Scanner(System.in);
		int y2 = scanner4.nextInt();
		
		PPoint p2 = new PPoint(x2, y2);
		
		
		//print the points
		System.out.println("The first point has coordinates: "+p1.toString());
		System.out.println("The second point has coordinates: "+p2.toString());
		
		
		//print distance from origin
		double dp1 = p1.distanceFromOrigin();
		double dp2 = p2.distanceFromOrigin();
		System.out.println("The distance from point 1 to the origin is: "+dp1);
		System.out.println("The distance from point 2 to the origin is: "+dp2);
	}
}