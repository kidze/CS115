public class PeopleClient
{
	public static void main(String[] args)
	{
		People person1 = new People();
		
		System.out.println(person1.getFirstName());
		System.out.println(person1.getLastName());
		System.out.println(person1.getSocialSecurity());
		System.out.println(person1.getHeight());
		System.out.println();
		
		person1.setFirstName("Mindy");
		person1.setLastName("Doe");
		person1.setSocialSecurity(345678902);
		person1.setHeight(5.5);
		
		System.out.println(person1.getFirstName());
		System.out.println(person1.getLastName());
		System.out.println(person1.getSocialSecurity());
		System.out.println(person1.getHeight());
		System.out.println();
		
		People person2 = new People("Yen","Nguyen",123456789,5.0);
		
		System.out.println(person2.getFirstName());
		System.out.println(person2.getLastName());
		System.out.println(person2.getSocialSecurity());
		System.out.println(person2.getHeight());
		System.out.println();
		
		person2.setFirstName("John");
		person2.setLastName("Brown");
		person2.setSocialSecurity(890345678);
		person2.setHeight(5.94);
		
		System.out.println(person2.getFirstName());
		System.out.println(person2.getLastName());
		System.out.println(person2.getSocialSecurity());
		System.out.println(person2.getHeight());
		System.out.println();
	}
}