public class People  {
               String firstName=" ";
                String lastName=" ";
	int socialSecurity=0;
	double height=0.0;
                 public People()
	{
                                                    firstName="AnyName";
		lastName="AnyName";
		socialSecurity=123456789;
		height=5.8;
	}
	
	public People(String fn, String ln, int ssn, double ht)
	{
                                                     firstName=fn;
		lastName=ln;
		socialSecurity=ssn;
		height=ht;
	}

	public String getFirstName()
	{
		return firstName;
	}

	public String getLastName()
	{
		return lastName;
	}

	public int getSocialSecurity()
	{
		return socialSecurity;
	}

	public double getHeight()
	{
		return height;
	}

	public void setFirstName(String fina)
	{
		firstName=fina;
	}

	public void setLastName(String lana)
	{
		lastName=lana;
	}

	public void setSocialSecurity(int sosec)
	{
		socialSecurity=sosec;
	}

	public void setHeight(double hei)
	{
		height=hei;
	}

}
