public class Winner
{
	Participant participant;
	Award award;
	Vehicle vehicle;
	
	public Winner()
	{
		participant = new Participant();
		award = new Award();
		vehicle = new Vehicle();
		participant.setWin(true);
	}
	public Winner(Participant p, Award a)
	{
		participant = p;
		award = a;
		vehicle = new Vehicle(a.getType());
		participant.setWin(true);
	}
	
	//accessors
	public String getFirstName(){return participant.getFirstName();}
	public String getLastName(){return participant.getLastName();}
	public int getSSN(){return participant.getSSN();}
	public int getLotteryNumber(){return participant.getLotteryNumber();}
	public int getCarID(){return vehicle.getVehicleID();}
	public int getCurrentID(){return vehicle.getCurrentID();}
	public int getAcceleration(){return vehicle.getAcceleration();}
	public boolean getWin(){return participant.getWin();}
	public double getTime(){return vehicle.getTime();}
	public double getVelocity(){return vehicle.getVelocity();}
	
	//mutators
	public void setAcceleration(int a){vehicle.setAcceleration(a);}
	public void setDistance(double d){vehicle.setDistance(d);}
	
	//calculate time
	public void calculateTime(){
		double t = Math.sqrt((2*vehicle.getDistance())/vehicle.getAcceleration());
		vehicle.setTime(t);
	}
	//calculate velocity
	public void calculateVelocity(){
		double v = vehicle.getAcceleration()*vehicle.getTime();
		vehicle.setVelocity(v);
	}
	
	//toString()
	public String toString()
	{	return "Name: "+participant.getFirstName()+" "+participant.getLastName()+". \t\tSSN: "+participant.getSSN()+". \t\tLottery number: "
	+participant.getLotteryNumber()+ ". \t\tType of car won: "+award.getType()+ ". \t\tID of car: "+ vehicle.getCurrentID()+ ". \t\tPrice of car won: "
	+award.getPrice();}
		
	//printRace
	public String printRace()
	{return participant.getFirstName()+" "+participant.getLastName()+".\t\tAcceleration: "+vehicle.getAcceleration()+". \t\tID of car: "
	+vehicle.getCurrentID()+".\t\tTime traveled: "+vehicle.getTime()+".\t\tFinal velocity: "+vehicle.getVelocity();}
	
	//print sequence
	public String printSequence()
	{return "ID of Car: "+vehicle.getCurrentID()+".\t\tAcceleration: "+vehicle.getAcceleration();}
}