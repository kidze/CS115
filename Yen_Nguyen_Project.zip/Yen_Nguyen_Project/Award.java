public class Award
{
	int price = 0;
	String type = "";
	String drive = "";
	
	public Award()
	{
		price = 0;
		type = "";
		drive = "";
	}
	public Award(int p, String t, String d)
	{
		price = p;
		type = t;
		drive = d;
	}
	
	//accessors
	public int getPrice(){return price;}
	public String getType(){return type;}
	public String getDrive(){return drive;}
	
	//mutators
	public void setPrice(int p){price = p;}
	public void setType(String t){type = t;}
	public void setDrive(String d){drive = d;}
	
	//toString()
	public String toString()
	{return "Pricec: "+price+". Type: "+type+". Drive: "+drive;}
}