import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.util.StringTokenizer;
public class LotteryProgram
{
	static int numOfParticipants = 0;
	static int numOfCheaters = 0;
	static int numOfAwards = 0;
	static Participant[] pArray = null;
	static Award[] aArray = null;
	static Participant[] disqualified = null;
	static Participant[] qualified = null;
	static Winner[] winners = null;
	static int[] accelerationArray = null;
	static Participant[] losers = null;
	
	public static void main(String[] args)
	{
		//create a LotteryProgram class
		LotteryProgram game = new LotteryProgram();
		//scan the files
		StringTokenizer[] pTokens = null;
		StringTokenizer[] aTokens = null;
		try{
			//participants
			File participantsFile = new File("participants.txt");
			Scanner scan1 = new Scanner(participantsFile);
			//count num of lines
			while(scan1.hasNextLine()){
				scan1.nextLine();
				numOfParticipants++;
			}
			pTokens = new StringTokenizer[numOfParticipants];
			//set lines to token array
			Scanner scan2 = new Scanner(participantsFile);
			for(int i = 0; i <= numOfParticipants - 1; i++){
				pTokens[i] = new StringTokenizer(scan2.nextLine(),"!");
			}
			//awards
			File awardsFile = new File("awards.txt");
			Scanner scan3 = new Scanner(awardsFile);
			//count num of lines
			while(scan3.hasNextLine()){
				scan3.nextLine();
				numOfAwards++;
			}
			aTokens = new StringTokenizer[numOfAwards];
			//set lines to token array
			Scanner scan4 = new Scanner(awardsFile);
			for(int i = 0; i <= numOfAwards - 1; i++){
				aTokens[i] = new StringTokenizer(scan4.nextLine(),":");
			}
		}
		catch(IOException e){
			System.out.println("There is something wrong with the participantsFile");
		}
		//create Participant objects
		pArray = new Participant[numOfParticipants];
		for(int i = 0; i<=numOfParticipants-1; i++){
			pArray[i] = new Participant(pTokens[i].nextToken(), pTokens[i].nextToken(), Integer.parseInt(pTokens[i].nextToken()), Integer.parseInt(pTokens[i].nextToken()));
		}
		//create Award objects
		aArray = new Award[numOfAwards];
		for(int i = 0; i<=numOfAwards-1; i++){
			aArray[i] = new Award(Integer.parseInt(aTokens[i].nextToken()), aTokens[i].nextToken(), aTokens[i].nextToken());
		}
		//look for cheaters
		for(int i = 1; i<= pArray.length-1; i++){
			for(int j = 0; j < i; j++){
				if(pArray[i].equals(pArray[j])){
					pArray[i].setCheat(true);
					pArray[j].setCheat(true);
				}
			}
		}
		//count the number of cheaters
		int numOfCheaters = 0;
		for(int i = 0; i<= pArray.length-1; i++){
			if(pArray[i].getCheat())
				numOfCheaters++;
		}
		//create disqualified and qualified arrays
		disqualified = new Participant[numOfCheaters];
		qualified = new Participant[numOfParticipants - numOfCheaters];
		//put participants in disqualified and qualified arrays
		int dIndex = 0;
		int qIndex = 0;
		while(dIndex <= disqualified.length-1 || qIndex <= qualified.length-1){
			for(int i = 0; i<=pArray.length-1; i++)
				if(pArray[i].getCheat()){
					disqualified[dIndex] = pArray[i];
					dIndex++;
				}
				else{
					qualified[qIndex] = pArray[i];
					qIndex++;
				}
		}
		//draw 10 numbers ranging from 1 to the length of qualified and put into luckyIndex array
		int[] luckyIndex = new int[10];
		for(int i = 0; i <= luckyIndex.length-1; i++){
			luckyIndex[i] = (int)(0 + Math.random()*qualified.length);//draw action (uniform probability)
		}
		//fix duplicate luckyIndex
		for(int i = 1; i <= luckyIndex.length-1; i++){
			if(game.haveDuplicates(luckyIndex, i)){
				luckyIndex[i] = (int)(0 + Math.random()*qualified.length);
				i--;
			}
		}
		//create a winner array of length 10
		winners = new Winner[10];
		//create 10 Winner objects from 10 lucky indexs and put them in winners array
		for(int i = 0; i<= winners.length-1; i++){
			winners[i] = new Winner(qualified[luckyIndex[i]], aArray[i]);
		}
		//create array of acceleration
		accelerationArray = new int[10];
		//set random data to accelerationArray
		for(int i = 0; i<= accelerationArray.length-1; i++){
			accelerationArray[i] = (int)(1 + Math.random()*20);
		}
		//fix acceleration duplicate
		for(int i = 1; i <= accelerationArray.length-1; i++){
			if(game.haveDuplicates(accelerationArray, i)){
				accelerationArray[i] = (int)(1 + Math.random()*20);
				i--;
			}
		}//every acceleration is unique by now
		//assign acceleration to winners, then assign distance, then calculate time and velocity
		for(int i = 0; i<= winners.length-1;i++){
			winners[i].setAcceleration(accelerationArray[i]);
			winners[i].setDistance(50000);
			winners[i].calculateTime();
			winners[i].calculateVelocity();
		}
		//make a losers array
		losers = new Participant[numOfParticipants - winners.length];
		int loserIndex = 0;
		//put the losers into the losers array 
		while(loserIndex <= losers.length-1){
			for(int i = 0; i<= pArray.length-1; i++){
				if(pArray[i].getWin() != true){
					losers[loserIndex] = pArray[i];
					loserIndex++;
				}
			}
		}
		//printing output
		//print winner toString
		System.out.println("The winners are:");
		for(int i = 0; i<= winners.length-1; i++){
			System.out.println(winners[i].toString());
		}
		
		//print losers name
		System.out.println("\nLosers' name:");
		for(int i = 0; i <= losers.length-1; i++){
			System.out.println("\t"+losers[i].printName());
		}
		
		//print cheaters
		if(disqualified.length == 0){
			System.out.println("\nThere were no cheaters.");
		}
		else{
			System.out.println("\nCheaters' name: ");
			for(int i = 0; i<= disqualified.length-1; i++){
				System.out.println("\t"+disqualified[i].printName());
			}
		}
		
		//sort the winners array from shortest time to longest time using two loops
		Winner personWithLongestTime = new Winner();
		for(int i = 0; i<= winners.length-2; i++){
			for(int j = i+1; j<= winners.length-1; j++){
				if(winners[i].getTime() > winners[j].getTime()){
					personWithLongestTime = winners[i];		//
					winners[i] = winners[j];				// --> swap place
					winners[j] = personWithLongestTime;		//
				}
			}
		}
		//print the winner of the race
		System.out.println("\nThe person that won the race is: "+winners[0].printRace());
		//print sequence
		System.out.println("\n The sequence is: ");
		for(int i = 0; i<= winners.length-1;i++){
			System.out.println(i+1 + ": "+winners[i].printSequence());
		}
	}
	
	//checking duplicates method
	public boolean haveDuplicates(int[] numberarray, int index){
		int counter = 0;
		for(int i = 0; i < index; i++)
		{
			if(numberarray[index] == numberarray[i])
				counter++;
		}
		if(counter>0) return true;
		else return false;
	}
}