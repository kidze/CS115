public class Participant
{
	String firstName = "";
	String lastName = "";
	int ssn = 0;
	int lotteryNumber = 0;
	boolean win = false;
	boolean isCheater = false;
	
	public Participant()
	{
		firstName = "";
		lastName = "";
		ssn = 0;
		lotteryNumber = 0;
		win = false;
		isCheater = false;
	}
	public Participant(String f, String l, int s, int ln)
	{
		firstName = f;
		lastName = l;
		ssn = s;
		lotteryNumber = ln;
		isCheater = false;
		win = false;
	}
	
	//accessors
	public String getFirstName(){return firstName;}
	public String getLastName(){return lastName;}
	public int getSSN(){return ssn;}
	public int getLotteryNumber(){return lotteryNumber;}
	public boolean getCheat(){return isCheater;}
	public boolean getWin(){return win;}
	
	//mutators
	public void setFirstName(String fn){firstName = fn;}
	public void setLastName(String ln){lastName = ln;}
	public void setSSN(int s){ssn = s;}
	public void setLotteryNumber(int l){lotteryNumber = l;}
	public void setCheat(boolean c){isCheater = c;}
	public void setWin(boolean w){win = w;}
	
	//toString()
	public String toString()
	{	return "Name: "+firstName+" "+lastName+". SSN: "+ssn+". Lottery number: "+lotteryNumber;}
	
	//print name
	public String printName()
	{return firstName+ " " + lastName;}
	//equals
	public boolean equals(Participant p)
	{
		if(this.getSSN() == p.getSSN())
			return true;
		else
			return false;
	}
}