import java.util.Scanner;
import java.util.StringTokenizer;

public class Task2
{
	public static void main(String[] args)
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter your name, userID and password (separated by commas, no space)");
		String inputString = scanner.next();
		StringTokenizer tokenizer =  new StringTokenizer(inputString,",");
		String name = tokenizer.nextToken();
		String userID = tokenizer.nextToken();
		String password = tokenizer.nextToken();
		
		if((userID.equals("admin"))&&(password.equals("open")))
			System.out.println("Welcome "+name);
		else if(userID.equals("admin"))
			System.out.println("Wrong password "+name);
		else if(password.equals("open"))
			System.out.println("Wrong userID "+name);
		else
			System.out.println("Wrong userID and wrong password "+name);
		
		System.out.println(name+"\n"+userID+"\n"+password);
		
	}
}