import java.util.Scanner;

public class Season
{
	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		System.out.println("enter the temperature(whole number)");
		int temperature = scan.nextInt();
		if(temperature>=90)
			System.out.println("summer");
		else if(temperature>=70)
			System.out.println("spring");
		else if(temperature>=50)
			System.out.println("fall");
		else if((temperature>110)||(temperature<-5))
			System.out.println("The temperature entered is outside the valid range");
		else
			System.out.println("winter");
	}
}