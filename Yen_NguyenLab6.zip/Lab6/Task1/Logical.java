import java.util.Scanner;

public class Logical
{
	public static void main(String[] args)
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a whole number");
		int number = scanner.nextInt();
		
		if((number>=10)&&(number<20))
			System.out.println(Math.pow(10,number));
		else if((number>=0)&&(number<10))
			System.out.println(100*number);
		else if(number == -1)
			System.exit(0);
		else
			System.out.println("the value is invalid");
	}
}