import javax.swing.JOptionPane;
import java.util.Scanner;

public class PeopleClient
{
	public static void main(String[] args)
	{
		Scanner scanner = new Scanner(System.in);
		//scan for values
		System.out.println("Please enter person2's first name");
		String firstname = scanner.next();
		
		System.out.println("Please enter person2's last name");
		String lastname = scanner.next();
		
		System.out.println("Please enter person2's social security number");
		int ssn = scanner.nextInt();
		
		System.out.println("Please enter person2's height");
		double height = scanner.nextDouble();
		
		//person2
		People person2 = new People(firstname, lastname, ssn, height);
		
		//values from command line
		String fn1 = args[0];
		String ln1 = args[1];
		int ssn1 = Integer.parseInt(args[2]);
		double height1 = Double.parseDouble(args[3]);
		
		//person1
		People person1 = new People(fn1, ln1, ssn1, height1);
		
		//output values of 4 people
		System.out.println(person1.toString());
		System.out.println(person2.toString());
		
		//test equality
		if(person1.equals(person2))
			System.out.println("Object 1 and object 2 are equal");
		else
			System.out.println("Object 1 and object 2 are not equal");

	}
}